// Type casting.

#include <stdio.h>

int main() {
float x;
double y;

  x = -10.3;
  y = x;

  fprintf(stdout,"%f %lf\n",x,y);

}
