// Type casting.

#include <stdio.h>

int main() {
int x;
char y;

  x = 1;
  y = '1';

  x = x + y;

  fprintf(stdout,"%d\n",x);

}
