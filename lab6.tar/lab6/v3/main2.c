// Type casting.

#include <stdio.h>

int main() {
float y;
int x;

  y = 10.8;
  x = y;

  fprintf(stdout,"%d\n",x);

}
