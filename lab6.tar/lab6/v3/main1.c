// Type casting.

#include <stdio.h>

int main() {

int x;
float y;

  x = 4000000000;
  y = x;

  fprintf(stdout,"%d\n",x);
  fprintf(stdout,"%f\n",y);

}
