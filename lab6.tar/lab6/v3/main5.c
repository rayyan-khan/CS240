// Type casting.

#include <stdio.h>

int main() {

int x;
unsigned int y;

  x = -10;
  y = x;

  fprintf(stdout,"%d %u\n", x, y);
}
