// Function prototype declarations.

void abc(void);
void xyz(int, int);
