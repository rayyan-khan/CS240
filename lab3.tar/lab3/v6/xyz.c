#include <stdio.h>


void xyz(int a, int b) {

  printf("Inside xyz\n");

  return;
}
