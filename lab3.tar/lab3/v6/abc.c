#include <stdio.h>
#include "myapp.h"

void abc(void) {

  printf("Inside abc\n");

  xyz(7,3);

  return;
}
