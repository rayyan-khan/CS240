// Issues stemming from buffered I/O and debugging using
// output to stdout.

#include <stdio.h>

int main() {
int *a;

  a = 0; 
  *a = 100;

}
