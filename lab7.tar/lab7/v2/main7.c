#include <stdio.h>

int main() {
int x = 5, y = 7;

  printf("%d %d\n", x);

}
