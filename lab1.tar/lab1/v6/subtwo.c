/*	function subtwo(a,b) takes two
	float arguments a and b, subtracts b
	from a, and returns the result to 
	the calling function */

float subtwo(float a, float b)
{
float c;

// subtract the two arguments
  c = a - b;

  return c;
}
