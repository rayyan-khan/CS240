// version 2 of z = x - y
// that outputs z on the terminal
// using library function printf()

#include <stdio.h>

void main()
{
int x, y, z;

// initialize
  x = 7;
  y = 3;

/* compute */
  z = x - y;

// output result
  printf("result of %d - %d equals %d\n", x, y, z);

}
