float subtwo(float, float);
