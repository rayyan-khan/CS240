/*	function subtwo(a,b) takes two
	float arguments a and b, subtracts b
	from a, and returns the result to 
	the calling function */

float subtwo(float a, float b)
{
float c;

// subtract b from a
  c = a - b;

  return c;
}
