// Another passing by reference exercise.

#include <stdio.h>

int main()
{
void modv(int *);
int x;

  x = 7;

  printf("%d\n",x);
  printf("%p\n",&x);

  modv(&x);

  printf("%d\n",x);
  printf("%p\n",&x);

}


void modv(int *a)
{
  printf("inside modv: %p\n",a);
  *a = 2;
}
