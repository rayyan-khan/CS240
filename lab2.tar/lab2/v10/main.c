// Basic string processing.

#include <stdio.h>


int main()
{
int i;
char u[7]; 

  u[0] = 'P';
  u[1] = 'U';
  u[2] = 'R';
  u[3] = 'D';
  u[4] = 'U';
  u[5] = 'E';
  u[6] = '\0';

  printf("%s\n", u);

}
