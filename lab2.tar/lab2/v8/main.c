// Pointers and arrays.

#include <stdio.h>


int main()
{
int *abc;

  *abc = 100;
  *(abc+1) = 200;
  *(abc+2) = 300;

  printf("%d\n",*abc);
  printf("%d\n",*(abc+1));
  printf("%d\n",*(abc+2));

}
